/*
 * uart7_com.h
 *
 *  Created on: Nov 16, 2020
 *      Author: marcl
 */

#ifndef SRC_UART7_COM_H_
#define SRC_UART7_COM_H_

#define MAX_BUFFER_SIZE 10

void uart_com(void *argument);


#endif /* SRC_UART7_COM_H_ */
